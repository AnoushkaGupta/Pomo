import React from 'react'; 
import Login from '../../components/login/login.component';


class AboutPage extends React.Component {
    render() {
                return(
                    <div className='about'>
                        <Login/>
                    </div>
                ) 
            }
}
export default(AboutPage);